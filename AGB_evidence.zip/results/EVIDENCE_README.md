# Generated evidence — proofread submission candidate

Start with the calculated CSV tables in this directory. Follow each query back to source records.

| Output | Meaning |
|---|---|
| `table_V_structural_arithmetic.csv` | Single-edge and attribute perturbations. |
| `table_VI_support_controls.csv` | Four policies over all structured support states. |
| `table_VII_boutique.csv` | Full/masked M1/M2/M2-CW reconstruction. |
| `table_VIII_membership.csv` | Four-application M1/MP/M2 and held-out membership confidence. |
| `table_IX_replay.csv` | Annotated connection/path results for ten paired applications. |
| `calibration/annotated/results.json` | Positive-proposal calibration, ECE and selection. |

## Trace the evidence

`boutique/queries.json` records Q2/Q4 paths and source locators. `membership/confidence_predictions.csv` records each held-out pair. `replay/annotation_records.json` preserves source-study labels and acquisition locations. `calibration/annotated/folds.json` shows exactly which other applications fitted each score.

## Scope

The default replay uses annotated TP/FP connection records, not rerun external tools. Raw directions are separately evaluated using explicitly named alignment variants. Input annotations are a documented browser transcription; raw exports are retained projections. See `validation/VERIFICATION.md` in the code package for claim-level checks and the unresolved raw-sensitivity threshold statement. Tables I, III and IV and Figures 1–5 describe the method; they are not new observations.

Complete mapping: `evidence/evidence_index.csv`.
