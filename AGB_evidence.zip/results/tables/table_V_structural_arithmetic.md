# Table V: structural arithmetic

Type: COMPUTED_OR_COMPUTATION_LEDGER.

| operation | m | exact_f1 | edge_f1 |
| --- | --- | --- | --- |
| Delete one true edge | 8 | 14/15 | 0.9333333333333333 |
| Delete one true edge | 9 | 16/17 | 0.9411764705882353 |
| Insert one false edge | 8 | 16/17 | 0.9411764705882353 |
| Insert one false edge | 9 | 18/19 | 0.9473684210526315 |
| Change only a zone attribute | 8 or 9 | 1 | 1.0 |
