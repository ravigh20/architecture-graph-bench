# Table VII: boutique

Type: COMPUTED_OR_COMPUTATION_LEDGER.

| condition | method | nodes | edges | node_f1 | edge_f1 | edge_f1_exact | tp | fp | fn | node_tp | node_fp | node_fn | Ds | De | accepted | query_count | coverage | unsupported | UCR_q | excluded_endpoints | processing |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| full | M1 | 24 | 27 | 1.0 | 0.9818181818181818 | 54/55 | 27 | 0 | 1 | 24 | 0 | 0 | 0.375 | 0.5 | 4 | 8 | 0.5 | 0 | 0.0 | 1 | FRESH_DETERMINISTIC_EXTRACTION |
| full | M2 | 24 | 28 | 1.0 | 1.0 | 1 | 28 | 0 | 0 | 24 | 0 | 0 | 0.0 | 0.0 | 8 | 8 | 1.0 | 0 | 0.0 | 1 | FRESH_DETERMINISTIC_EXTRACTION |
| masked | M1 | 24 | 26 | 1.0 | 0.9629629629629629 | 26/27 | 26 | 0 | 2 | 24 | 0 | 0 | 0.5 | 0.375 | 3 | 8 | 0.375 | 0 | 0.0 | 1 | FRESH_DETERMINISTIC_EXTRACTION |
| masked | M2 | 24 | 27 | 1.0 | 0.9818181818181818 | 54/55 | 27 | 0 | 1 | 24 | 0 | 0 | 0.25 | 0.0 | 6 | 8 | 0.75 | 0 | 0.0 | 1 | FRESH_DETERMINISTIC_EXTRACTION |
| masked | M2-CW | 24 | 27 | 1.0 | 0.9818181818181818 | 54/55 | 27 | 0 | 1 | 24 | 0 | 0 | 0.25 | 0.25 | 8 | 8 | 1.0 | 2 | 0.25 | 1 | FRESH_DETERMINISTIC_EXTRACTION |
