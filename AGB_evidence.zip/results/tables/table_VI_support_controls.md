# Table VI: support controls

Type: COMPUTED_OR_COMPUTATION_LEDGER.

| policy | De | accepted | coverage | UCR |
| --- | --- | --- | --- | --- |
| Evidence preserving | 0.0 | 512 | 0.5 | 0.0 |
| Positive precedence | 0.25 | 768 | 0.75 | 0.3333333333333333 |
| Closed world | 0.5 | 1024 | 1.0 | 0.5 |
| Always unknown | 0.75 | 0 | 0.0 | N/A |
