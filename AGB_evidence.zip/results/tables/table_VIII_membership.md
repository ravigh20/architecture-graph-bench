# Table VIII: membership

Type: COMPUTED_OR_COMPUTATION_LEDGER.

| application | pairs | reference_edges | M1_edge_f1 | MP_edge_f1 | M2_edge_f1 | M1_wrong_answers | MP_wrong_answers | M2_wrong_answers | queries | fitted_brier | hard_name_brier | fixed_09_brier |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| bookinfo | 24 | 6 | 0.0 | 1.0 | 1.0 | 5 | 0 | 0 | 8 | 0.20251913070094887 | 0.25 | 0.21 |
| sockshop | 196 | 14 | 1.0 | 0.7777777777777778 | 1.0 | 0 | 8 | 0 | 28 | 0.03263509674466915 | 0.0 | 0.01 |
| voting | 20 | 4 | 1.0 | 1.0 | 1.0 | 0 | 0 | 0 | 8 | 0.000574016620498615 | 0.0 | 0.01 |
| guestbook | 9 | 3 | 1.0 | 1.0 | 1.0 | 0 | 0 | 0 | 6 | 0.0008484504913076342 | 0.0 | 0.01 |
