# Table III: tasks

Type: DESCRIPTIVE_FROM_MANUSCRIPT.

| task | recovery_target | scoring_object |
| --- | --- | --- |
| T1 | Typed entities | Canonical node and type. |
| T2 | Typed relationships | Directed typed edge. |
| T3 | Zones and boundaries | Membership and crossing. |
| T4 | Identity and controls | Binding or mediation assertion. |
| T5 | Provenance | Source-link validity and sufficient support. |
| T6 | Epistemic state | State on aligned assertion. |
| T7 | Query preservation | Outcome and supporting witness. |
