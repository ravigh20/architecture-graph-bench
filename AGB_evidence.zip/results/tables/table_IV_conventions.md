# Table IV: conventions

Type: DESCRIPTIVE_FROM_MANUSCRIPT.

| condition | treatment |
| --- | --- |
| Gold and prediction both empty | F1 = N/A; disclose excluded count. |
| Exactly one set empty | F1 = 0 for the nonempty scoring population. |
| No accepted singleton claims | UCR = N/A; coverage = 0. |
| No applicable queries | Divergence is undefined. |
| Unsupported negative conclusion | Unknown unless absence is justified. |
| Outside-scope assertion | Unadjudicated; no automatic truth label. |
| Conflicting current sources | Preserve conflict; disclose precedence. |
| Only matched attributes scored | Also report alignment coverage and recall. |
| Malformed or failed output | Retain in the run inventory; do not silently drop. |
