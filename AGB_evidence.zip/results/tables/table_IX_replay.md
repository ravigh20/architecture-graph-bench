# Table IX: replay

Type: COMPUTED_OR_COMPUTATION_LEDGER.

| application | C_F1 | M_F1 | C_errors | M_errors | queries | F1_tied | ranking_reversed |
| --- | --- | --- | --- | --- | --- | --- | --- |
| java-microservice | 0.8055555555555556 | 0.5833333333333334 | 23 | 45 | 210 | False | False |
| microservice | 0.9230769230769231 | 0.5555555555555556 | 6 | 33 | 42 | False | False |
| microservice-kafka | 0.8888888888888888 | 0.9090909090909091 | 4 | 6 | 56 | False | True |
| microservices-basics-spring-boot | 0.7916666666666666 | 0.42105263157894735 | 42 | 78 | 132 | False | False |
| microservices-sample | 1.0 | 0.5714285714285714 | 0 | 42 | 210 | False | False |
| spring-boot-microservices | 0.8 | 0.7619047619047619 | 40 | 38 | 110 | False | True |
| spring-cloud-netflix-example | 0.9454545454545454 | 0.9454545454545454 | 8 | 16 | 90 | True | False |
| spring-netflix-oss-microservices | 0.8936170212765957 | 0.8 | 20 | 68 | 110 | False | False |
| spring-petclinic-microservices | 0.9642857142857143 | 0.5641025641025641 | 11 | 72 | 132 | False | False |
| tap-and-eat-microservices | 1.0 | 0.4 | 0 | 19 | 72 | False | False |
