# Table I: related work

Type: DESCRIPTIVE_FROM_MANUSCRIPT.

| work | reported_target | distinction |
| --- | --- | --- |
| Trace-link studies [2]–[4], [13] | Documentation/model/code links and inconsistencies. | Relates source support to typed security assertions and condition-specific evidence states. |
| SARIF; static-tool comparison [14], [15] | Recovered structure and its characteristics. | Separates structural error from selected query consequences. |
| ArchAgent; ArchBench [9], [10] | Architecture recovery; extensible architecture-task evaluation. | Specifies structural, query, and evidence-support evaluation for reconstructed graphs. |
| SAKE [11] | Architectural-knowledge question answering. | Evaluates a recovered graph and the support for its assertions. |
| EVerest [49] | Security-labeled requirements, architecture, code, and trace links. | Evaluates support labels as available security evidence changes. |
| AuthentiCity [37] | Multi-source graphs, provenance-aware queries, and answerability. | Applies related concerns to software-security boundaries, controls, and reconstruction errors. |
