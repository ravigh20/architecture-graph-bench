# Table II: support transitions

Type: COMPUTED_OR_COMPUTATION_LEDGER.

| available_evidence | state |
| --- | --- |
| Current positive binding | T |
| Only binding removed | U |
| Current positive and negative | C |
| Negative support only | F |
| Out-of-interval binding only | U |
