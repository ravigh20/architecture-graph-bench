# Candidate reference: review required

Automatically generated candidate; not independently validated. A separate implementation does not eliminate shared-rule bias with M2. Source hashes detect byte changes; they do not authenticate origins, reviewer identity, or the correctness of the reference.

Inspect the original YAML, each node/edge source locator, query_evidence.json, the finite-scope completeness assumption, exclusions, and mask.json.

Only edit decision, reviewer and notes in review.csv. Use APPROVE after actually checking a record; use REJECT or leave PENDING otherwise. Do not edit record IDs, items, source locations, or candidate hashes. Every row, including scope and query negatives, needs review. Negative answers require inspecting the complete scoped input.

The finalize command records the supplied review; it cannot verify reviewer identity or independence. Do not open participant predictions before conducting a blinded review. Source consistency is not a substitute for independent review.

Corrections require a new candidate, rechecking affected claims and a new review. The default paper workflow continues to use its unchanged historical reference.
